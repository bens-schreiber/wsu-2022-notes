#pragma once

typedef struct {
    int diceSum;
    int wager;
    int houseBalance;
    int playerBalance;
    int crapsPoint;
    int round;
} CrapsGame;