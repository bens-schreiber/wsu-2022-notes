#pragma once
#include <stdlib.h>

// Roll a die and return the value it rolled
int droll();

// Roll two dice, return sum
int dsroll();