# Programming Assignment 3 CPTS 121
## Benjamin Schreiber, Lab 5

# Notes for grader:
- On a mac using VSCode
- Defs folder contains the library for reading and writing to files.
- In folder containers the input text to read from
- Out folder contains the output text to write to
- All values are kept as accurate as possible. No rounding. Unsure if this is what is wanted as the output for demonstration rounds, but I don't see it specifically telling us to do that anywhere.