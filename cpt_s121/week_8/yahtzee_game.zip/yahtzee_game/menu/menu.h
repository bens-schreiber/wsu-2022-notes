#pragma once
#include "../messages/messages.h"
#include "../game/game.h"
#include <stdio.h>
// Displays the starting menu. Returns -1 to exit the menu.
int displayMenu();