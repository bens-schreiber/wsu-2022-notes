#include "./menu/menu.h"

int main(int argc, char const *argv[])
{
    // Menu loop.
    while(displayMenu());
    return 0;
}
