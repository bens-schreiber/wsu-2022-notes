#pragma once

// Displays the starting menu. Returns 0 to exit
int displayMenu();