#include "./menu/menu.h"

int main(int argc, char const *argv[])
{
    while(displayMenu());
    return 0;
}
