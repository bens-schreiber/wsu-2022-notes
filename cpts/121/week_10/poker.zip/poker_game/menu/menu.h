#pragma once
#include "../log/log.h"
#include "../game/game.h"
#include "../tests/tests.h"

// displays the menu
// 1 if display 0 if no
int displayMenu();