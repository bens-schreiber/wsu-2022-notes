#include "../log/log.h"
#include "../game/poker-type.h"
#include "../game/game.h"
void runTests();