# Poker by Benjamin Schreiber
Change constants in utils/constants