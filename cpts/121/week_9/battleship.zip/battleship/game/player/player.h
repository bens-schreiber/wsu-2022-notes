#include "player_types.h"

// Fill shipMap with SHIPS_PER_PLAYER ships
void battleShipPlayerPlaceShips(BattleShipPlayer *player);

// Fill shipMap with SHIPS_PER_PLAYER ships
void battleShipPlayerGenerateShips(BattleShipPlayer *player);