#include <stdio.h>
#include <stdlib.h>

void setIntValue(const char *print, int *value);

void setDoubleValue(const char *print, double *value);

void startProblem(const char* problem);
