# Craps Game by Benjamin Schreiber
Inputs are not checked in any way currently.
The entire game has no win conditon, other than emptying the houses balance. Individual games can be won.