#include "../fitbit_data_t.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

FitbitResult *readAndComputeFitbitData(FILE *file);