#include "../fitbit_data_t.h"
#include <stdio.h>
void exportFitbitData(const FitbitResult *result, FILE *file);