#include "../fitbit/reader/reader.h"
#include "../fitbit/exporter/exporter.h"
void runTests(const int runTests, FitbitResult *result);