#pragma once
#define STRING_SIZE 0xFF
#define INPUT_FILE "./input/musicPlayList.csv"