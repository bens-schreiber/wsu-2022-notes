#include "../record/record.h"
#include "../commands/commands.h"
#include <stdio.h>

int displayMenu(Queue **queue);

void outMenuOptions();

int getIntInput();

void getInput();