#include "../record/record.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
Queue *readRecordsFromFile(FILE *input);